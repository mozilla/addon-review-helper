export const SET_TITLE = 'SET_TITLE'
export const SET_VERSION = 'SET_VERSION'
export const SET_NOTE_EXISTS = "SET_NOTE_EXISTS";