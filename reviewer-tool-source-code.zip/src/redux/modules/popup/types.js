export const SET_MENU_TYPE = "SET_MENU_TYPE";
export const MENU = "MENU";
export const NOTE = "NOTE";
export const CATEGORIES = "CATEGORIES";