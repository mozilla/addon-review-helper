
## Available Scripts

In the project directory, you can run:

### `npm run dev`

Runs the app in the development mode.<br />


### `npm run build`
Builds the app for production to the `dist` folder.<br />


